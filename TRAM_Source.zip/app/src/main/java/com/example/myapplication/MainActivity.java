package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class MainActivity extends AppCompatActivity {

    // declaring variables
    TextView txtMainWord;
    String mainWord;
    String DisplayWordString;
    char[] DisplayWordArray;
    ArrayList<String> ListofWords;
    EditText edtUserIn;
    TextView txtLettersGuessed;
    String lettersGuessed;
    TextView txtGuessesLeft;
    String GuessesLeft;
    final String messageWithLettersGuessed = "Letters tried :";

    final String WINNING_MESSAGE = "You Win!";
    Animation rotateAnimation;
    Animation scaleAnimation;
    Animation scaleAndRotateAnimation;
    void revealLetterInWord(char letter) //function definition
    {
        int letterPosition;
        letterPosition = mainWord.indexOf(letter);

        //if letter is in wordToBeGuessed, its index will be >= 0, and the while loop below will be executed
        while (letterPosition >= 0) {
            //replaces the blank dash with the correctly guessed letter
            DisplayWordArray[letterPosition] = mainWord.charAt(letterPosition);
            //checks for cases where the word has two or more of the same letter
            letterPosition = mainWord.indexOf(letter, letterPosition + 1);
        }

        DisplayWordString = String.valueOf(DisplayWordArray);
    }
    void displayWordOnScreen() {

        String formatString = ""; // initialized to an empty string

        for (char c : DisplayWordArray) { //traverse the character array
            formatString += c + " ";
        }

        txtMainWord.setText(formatString); //display formatted string on the screen

    }


    void initializeGame() {
//1.WORD

        //Shuffle arary list and get first element and then lastly remove it
        Collections.shuffle(ListofWords);
        mainWord = ListofWords.get(0);
        ListofWords.remove(0);
        // initialize character array
        DisplayWordArray = mainWord.toCharArray();

        //for loop to create lines under each letter
        for (int i = 1; i < DisplayWordArray.length - 1; i++) {
            DisplayWordArray[i] = '_';

        }

        // showing all occurences of the first character
        revealLetterInWord(DisplayWordArray[0]);

        // show all instances of of last character
        revealLetterInWord(DisplayWordArray[DisplayWordArray.length - 1]);

        //initialize string from cahr array in order to search

        DisplayWordString = String.valueOf(DisplayWordArray);

        // display word on screen
        displayWordOnScreen();

        //2 - Input and clear input
        edtUserIn.setText("");
        //3 Letters guessed
        lettersGuessed = " ";
        // Displaying letters guessed on screen
        txtLettersGuessed.setText(messageWithLettersGuessed);

        // Number of guesses left
        GuessesLeft = "X X X X X";
        txtGuessesLeft.setText(GuessesLeft);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListofWords = new ArrayList<String>();
        txtMainWord = (TextView) findViewById(R.id.txtMainWord);
        edtUserIn = (EditText) findViewById(R.id.edtUserIn);
        txtLettersGuessed = (TextView) findViewById(R.id.txtLettersGuessed);
        txtGuessesLeft = (TextView) findViewById(R.id.txtGuessesLeft);

        InputStream myInputStream = null;
        Scanner in = null;
        String aWord = "";
        try {
            InputStream inputStream = myInputStream = getAssets().open("database_file.txt"); // pulls in database_file.txt
            in = new Scanner(myInputStream);
            while (in.hasNext()) {
                aWord = in.next();
                ListofWords.add(aWord);
            }

        } catch (IOException e) {
            Toast.makeText(MainActivity.this, e.getClass().getSimpleName() + ":" + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
        // closing the scanner
        finally {
            if (in != null) {
                in.close();

            }
            // Closing InputStream ----
            try {

                if (myInputStream != null) {
                    myInputStream.close();
                }
            } catch (IOException e) {
                Toast.makeText(MainActivity.this, e.getClass().getSimpleName() + ": " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

        // Revealing Full Word
        initializeGame();
        edtUserIn.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    checkIfLetterIsInWord(s.charAt(0));

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    void checkIfLetterIsInWord(char letter) {
        //check if the letter was found inside the word to be guessed
        if (mainWord.indexOf(letter) >= 0) {

            //if the letter was not displayed
            if (DisplayWordString.indexOf(letter) < 0) {
                //fill underscores from initialization
                revealLetterInWord(letter);

                //update the changes on the screen
                displayWordOnScreen();

                //check for end of game (win)
                if (!DisplayWordString.contains("_")) {
                    txtGuessesLeft.setText(WINNING_MESSAGE);
                }
            }
        }
        //otherwise, if the letter was not found in the word
        else {
            //decrease the number of tries left, and show it on the screen
            decreaseAndDisplayTriesLeft();

            //check if the game is lost and reset Game to start Screen
            if (GuessesLeft.isEmpty()) {
                txtMainWord.setText(mainWord);
            }

        }
        if (lettersGuessed.indexOf(letter) < 0) {
            lettersGuessed += letter + ", ";
            String messageToBeDisplayed = messageWithLettersGuessed + lettersGuessed;
            txtLettersGuessed.setText(messageToBeDisplayed);
        }
        if (GuessesLeft.length() == 0) {
            txtMainWord.setText(letter);
        }
    }

    void decreaseAndDisplayTriesLeft() {

        if (!GuessesLeft.isEmpty()) {
            GuessesLeft = GuessesLeft.substring(0, GuessesLeft.length() - 2);
            txtGuessesLeft.setText(GuessesLeft);


        }
    }


    public void resetGame(View v)
    {
        initializeGame();
    }


    public void btnBack(View view) {
        Intent intent = new Intent(this, StartGameScreen.class);
        startActivity(intent);
    }


}